package com.jkdajac.lesson_1_6;

public interface Unit {
    int health = 100;
   public int damage();

}
