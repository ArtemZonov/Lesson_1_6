package com.jkdajac.lesson_1_6;

public interface Waterable {

    void swim();


}
