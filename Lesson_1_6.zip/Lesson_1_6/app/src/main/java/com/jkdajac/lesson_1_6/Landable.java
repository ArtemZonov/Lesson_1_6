package com.jkdajac.lesson_1_6;

public interface Landable  {

    void move();


}
